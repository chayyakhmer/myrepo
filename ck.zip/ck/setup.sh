pkg update
pkg install unzip
pkg install wget
mkdir cloak
cd /cloak
wget 
unzip
chmod +x ck-client
chmod +x run.sh
cd
cp /cloak/run.sh run.sh
chmod +x run.sh

